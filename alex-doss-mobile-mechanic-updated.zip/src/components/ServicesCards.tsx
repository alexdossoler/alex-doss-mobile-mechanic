import { Gauge, ShieldCheck, Wrench } from "lucide-react";

const items = [
  {
    title: "No-Start / Stalling",
    desc: "Crank/no start, stalls, intermittent issues.",
    Icon: Gauge,
  },
  {
    title: "Brakes",
    desc: "Pads/rotors, noise, vibration, pull diagnosis.",
    Icon: ShieldCheck,
  },
  {
    title: "Check Engine Light",
    desc: "Misfires, sensors, driveability diagnostics.",
    Icon: Wrench,
  },
];

export default function ServicesCards() {
  return (
    <section id="services" className="bg-white">
      <div className="mx-auto max-w-6xl px-4 py-14">
        <div className="flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <h2 className="text-3xl font-bold tracking-tight text-zinc-900">Common Services</h2>
            <p className="mt-1 text-sm text-zinc-600">Dependable repairs — on your terms.</p>
          </div>
        </div>

        <div className="mt-8 grid gap-5 lg:grid-cols-3">
          {items.map(({ title, desc, Icon }) => (
            <div
              key={title}
              className="overflow-hidden rounded-2xl border border-zinc-200 bg-white shadow-sm"
            >
              <div className="flex min-h-[120px]">
                <div className="flex-1 p-5">
                  <div className="text-base font-semibold text-zinc-900">{title}</div>
                  <div className="mt-2 text-sm text-zinc-600">{desc}</div>
                </div>

                {/* right image panel (simple, clean – matches screenshot feel) */}
                <div className="relative w-[44%] bg-gradient-to-br from-zinc-100 to-zinc-200">
                  <div className="absolute inset-0 opacity-30 [background:radial-gradient(circle_at_30%_30%,rgba(0,0,0,0.15),transparent_60%)]" />
                  <div className="absolute bottom-4 left-4 rounded-xl bg-white/90 p-3 shadow-sm">
                    <Icon className="h-6 w-6 text-zinc-900" />
                  </div>
                </div>
              </div>

              <div className="border-t border-zinc-200 p-4 text-center">
                <a
                  href="#contact"
                  className="text-sm font-semibold text-zinc-900 hover:underline"
                >
                  Get pricing →
                </a>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-10 border-t border-zinc-200 pt-6 text-center text-sm font-semibold text-zinc-700">
          Diagnose first. Fix what's confirmed.
        </div>
      </div>
    </section>
  );
}

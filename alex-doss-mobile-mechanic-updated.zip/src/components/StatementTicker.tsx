"use client";

import { Swiper, SwiperSlide } from "swiper/react";
import { Autoplay } from "swiper/modules";

const lines = [
  "Diagnose first. Fix what's confirmed.",
  "Mobile service — we come to you.",
  "Clear communication and clean work.",
  "No tow if you can avoid it.",
];

export default function StatementTicker() {
  return (
    <section className="border-y border-zinc-200 bg-white py-6">
      <div className="mx-auto max-w-6xl px-4">
        <Swiper
          modules={[Autoplay]}
          autoplay={{ delay: 2200, disableOnInteraction: false }}
          loop
          slidesPerView={1}
        >
          {lines.map((t) => (
            <SwiperSlide key={t}>
              <div className="text-center text-sm font-semibold text-zinc-700">{t}</div>
            </SwiperSlide>
          ))}
        </Swiper>
      </div>
    </section>
  );
}

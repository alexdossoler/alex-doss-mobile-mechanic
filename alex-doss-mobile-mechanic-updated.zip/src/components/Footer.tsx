export default function Footer() {
  return (
    <footer className="bg-zinc-900 text-white">
      <div className="mx-auto max-w-6xl px-4 py-6">
        <div className="flex flex-col gap-2 text-sm sm:flex-row sm:items-center sm:justify-between">
          <div className="text-white/70">© {new Date().getFullYear()} Alex Doss Mobile Mechanic</div>
          <div className="text-white/80">
            Text: <span className="font-semibold text-white">(407) 234-5863</span>
          </div>
        </div>
      </div>
    </footer>
  );
}

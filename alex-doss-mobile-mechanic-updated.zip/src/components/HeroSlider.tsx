import { Clock, MapPin, Phone } from "lucide-react";

/**
 * Mechanic demo-style hero (static) to match the provided screenshot.
 * Background image: /public/hero-bg.png (swap anytime)
 */
export default function HeroSlider() {
  return (
    <section className="relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0">
        <div
          className="h-full w-full bg-cover bg-center"
          style={{ backgroundImage: "url(hero-bg.png)" }}
        />
        <div className="absolute inset-0 bg-zinc-950/55" />
        <div className="absolute inset-0 [background:radial-gradient(circle_at_25%_20%,rgba(255,255,255,0.18),transparent_55%)]" />
      </div>

      <div className="relative mx-auto max-w-6xl px-4 pt-10 sm:pt-14">
        {/* Top hero content */}
        <div className="grid gap-8 lg:grid-cols-[1.2fr_0.8fr] lg:items-start">
          <div className="text-white">
            <div className="text-xs font-semibold tracking-widest text-white/80">
              ALEX DOSS MOBILE MECHANIC
            </div>

            <h1 className="mt-3 text-3xl font-bold leading-tight sm:text-5xl">
              Mobile Mechanic —{" "}
              <span className="text-white/90">Diagnostics & Repairs</span> at Your Location
            </h1>

            <p className="mt-4 max-w-prose text-base text-white/80 sm:text-lg">
              No tow. No guessing. Clear next steps after diagnosis.
            </p>

            <div className="mt-6 flex flex-wrap gap-3">
              <a
                href="sms:+14072345863"
                className="rounded-xl bg-white px-5 py-3 text-sm font-semibold text-zinc-900 shadow-sm"
              >
                Text to Schedule
              </a>
              <a
                href="#services"
                className="rounded-xl border border-white/25 bg-white/0 px-5 py-3 text-sm font-semibold text-white backdrop-blur"
              >
                View Common Repairs
              </a>
            </div>

            <div className="mt-6 text-sm text-white/70">
              Serving: <span className="font-semibold text-white/85">Charlotte / Rock Hill / Spartanburg</span>
            </div>
          </div>

          {/* What to text us card */}
          <div className="rounded-2xl border border-white/15 bg-white/10 p-5 text-white backdrop-blur">
            <div className="text-base font-semibold">What to text us</div>
            <ul className="mt-3 space-y-2 text-sm text-white/80">
              <li>• Address / ZIP + best time window</li>
              <li>• Year / make / model + symptoms</li>
              <li>• Any codes (if you have them)</li>
              <li>• Photos/video if relevant</li>
            </ul>

            <div className="mt-4 rounded-xl border border-white/15 bg-zinc-950/35 p-4 text-sm">
              <div className="font-semibold text-white/90">Example:</div>
              <div className="mt-1 text-white/75">
                “2009 Honda Accord. Cranks but won’t start. Charlotte. Tuesday morning.”
              </div>
            </div>
          </div>
        </div>

        {/* Info strip */}
        <div id="contact" className="mt-10 grid gap-3 rounded-2xl border border-zinc-200 bg-white/95 p-4 text-zinc-900 shadow-sm sm:grid-cols-3">
          <div className="flex items-center gap-3 rounded-xl p-3">
            <div className="rounded-xl border border-zinc-200 p-2">
              <Phone className="h-4 w-4" />
            </div>
            <div>
              <div className="text-sm font-semibold">Text / Call</div>
              <div className="text-sm text-zinc-600">(407) 234-5863</div>
              <div className="text-xs text-zinc-500">Fast response by text</div>
            </div>
          </div>

          <div className="flex items-center gap-3 rounded-xl p-3">
            <div className="rounded-xl border border-zinc-200 p-2">
              <Clock className="h-4 w-4" />
            </div>
            <div>
              <div className="text-sm font-semibold">Hours</div>
              <div className="text-sm text-zinc-600">Mon—Sat</div>
              <div className="text-xs text-zinc-500">Flexible scheduling available</div>
            </div>
          </div>

          <div className="flex items-center gap-3 rounded-xl p-3">
            <div className="rounded-xl border border-zinc-200 p-2">
              <MapPin className="h-4 w-4" />
            </div>
            <div>
              <div className="text-sm font-semibold">Service Area</div>
              <div className="text-sm text-zinc-600">Carolinas</div>
              <div className="text-xs text-zinc-500">Charlotte / Rock Hill / Spartanburg</div>
            </div>
          </div>
        </div>

        <div className="h-10" />
      </div>
    </section>
  );
}

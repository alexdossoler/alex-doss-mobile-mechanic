import HeroSlider from "@/components/HeroSlider";
import ServicesCards from "@/components/ServicesCards";
import Footer from "@/components/Footer";

export default function Page() {
  return (
    <main>
      <HeroSlider />
      <ServicesCards />
      <Footer />
    </main>
  );
}

import React, { useState, useEffect, useRef } from "react";
import { createRoot } from "react-dom/client";

// --- Icons (Replacing lucide-react for standalone usage) ---
const Icons = {
  Phone: (props: any) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
  ),
  Clock: (props: any) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
  ),
  MapPin: (props: any) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></svg>
  ),
  Gauge: (props: any) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}><path d="m12 14 4-4"/><path d="M3.34 19a10 10 0 1 1 17.32 0"/></svg>
  ),
  ShieldCheck: (props: any) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10"/><path d="m9 12 2 2 4-4"/></svg>
  ),
  Battery: (props: any) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}><rect width="16" height="10" x="2" y="7" rx="2" ry="2"/><line x1="22" x2="22" y1="11" y2="13"/></svg>
  ),
  Wrench: (props: any) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/></svg>
  ),
  Fuel: (props: any) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}><line x1="3" x2="15" y1="22" y2="22"/><line x1="4" x2="14" y1="9" y2="9"/><path d="M14 22V4a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v18"/><path d="M14 13h2a2 2 0 0 1 2 2v2a2 2 0 0 0 2 2h0a2 2 0 0 0 2-2V9.83a2 2 0 0 0-.59-1.42L18 5"/></svg>
  ),
  Car: (props: any) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}><path d="M19 17h2c.6 0 1-.4 1-1v-3c0-.9-.7-1.7-1.5-1.9C18.7 10.6 16 10 16 10s-1.3-1.4-2.2-2.3c-.5-.4-1.1-.7-1.8-.7H5c-.6 0-1.1.4-1.4.9l-1.4 2.9A3.7 3.7 0 0 0 2 12v4c0 .6.4 1 1 1h2"/><circle cx="7" cy="17" r="2"/><circle cx="17" cy="17" r="2"/><path d="M14 17H9"/></svg>
  ),
};

// --- Custom Components ---

const HeroSlider = () => {
  const slides = [
    {
      kicker: "Mobile Mechanic",
      title: "Diagnostics & Repairs at Your Location",
      body: "No tow. No waiting room. Clear pricing after diagnosis.",
      cta: "Text to Schedule",
      href: "#contact",
    },
    {
      kicker: "Fast Turnarounds",
      title: "Brake • Battery • No-Start • Sensors",
      body: "We come to you with pro tools and real troubleshooting.",
      cta: "See Services",
      href: "#services",
    },
    {
      kicker: "Straight Talk",
      title: "Fix What’s Confirmed",
      body: "We diagnose first and only replace what’s necessary.",
      cta: "Get a Quote",
      href: "#contact",
    },
  ];

  const [current, setCurrent] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrent((prev) => (prev + 1) % slides.length);
    }, 4500);
    return () => clearInterval(timer);
  }, [slides.length]);

  return (
    <section className="relative overflow-hidden bg-zinc-900 h-[600px]">
      <div className="absolute inset-0 bg-gradient-to-b from-zinc-950 to-zinc-900" />
      <div className="absolute inset-0 opacity-20 [background:radial-gradient(circle_at_30%_20%,white,transparent_55%)]" />
      
      <div className="relative mx-auto max-w-6xl px-4 py-16 sm:py-20 h-full flex items-center">
        <div className="rounded-3xl border border-white/10 bg-white/5 backdrop-blur w-full overflow-hidden relative min-h-[450px]">
           {/* Slider Content */}
           {slides.map((s, idx) => (
            <div 
              key={idx}
              className={`absolute inset-0 transition-opacity duration-700 ease-in-out ${idx === current ? 'opacity-100 z-10' : 'opacity-0 z-0'}`}
            >
              <div className="grid gap-10 p-8 sm:p-12 md:grid-cols-2 md:items-center h-full">
                <div className="text-white">
                  <div className="text-sm font-semibold tracking-widest text-white/70 uppercase">
                    {s.kicker}
                  </div>
                  <h1 className="mt-3 text-3xl font-bold leading-tight sm:text-5xl">
                    {s.title}
                  </h1>
                  <p className="mt-4 max-w-prose text-lg text-white/80">{s.body}</p>
                  <div className="mt-7 flex flex-wrap gap-3">
                    <a
                      href={s.href}
                      className="rounded-2xl bg-white px-5 py-3 text-sm font-semibold text-zinc-900 shadow hover:bg-zinc-100 transition-colors"
                    >
                      {s.cta}
                    </a>
                    <a
                      href="#services"
                      className="rounded-2xl border border-white/20 px-5 py-3 text-sm font-semibold text-white hover:bg-white/10 transition-colors"
                    >
                      View Common Repairs
                    </a>
                  </div>
                  <div className="mt-6 text-sm text-white/60">
                    Serving: Charlotte • Rock Hill • Spartanburg (and nearby)
                  </div>
                </div>

                <div className="rounded-3xl border border-white/10 bg-white/5 p-6 text-white hidden md:block">
                  <div className="text-sm font-semibold text-white/70">What to text us</div>
                  <ul className="mt-3 space-y-2 text-sm text-white/80">
                    <li>• Address / ZIP + best time window</li>
                    <li>• Year / make / model + symptoms</li>
                    <li>• Any codes (if you have them)</li>
                    <li>• Photos/video if relevant</li>
                  </ul>
                  <div className="mt-5 rounded-2xl bg-zinc-950/40 p-4 text-sm">
                    <div className="font-semibold">Example</div>
                    <div className="mt-1 text-white/75">
                      “2014 Audi SQ5. Rough idle + oil leak. Rock Hill. Friday 2–5pm.”
                    </div>
                  </div>
                </div>
              </div>
            </div>
           ))}
           
           {/* Pagination Dots */}
           <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-20 flex gap-2">
             {slides.map((_, idx) => (
               <button
                 key={idx}
                 onClick={() => setCurrent(idx)}
                 className={`w-2 h-2 rounded-full transition-all duration-300 ${idx === current ? 'bg-white w-6' : 'bg-white/40'}`}
                 aria-label={`Go to slide ${idx + 1}`}
               />
             ))}
           </div>
        </div>
      </div>
    </section>
  );
};

const ContactStrip = () => {
  return (
    <section id="contact" className="border-b border-zinc-200 bg-zinc-50">
      <div className="mx-auto grid max-w-6xl gap-4 px-4 py-8 md:grid-cols-3">
        <div className="rounded-2xl bg-white p-5 shadow-sm border border-zinc-100">
          <div className="flex items-center gap-2 text-sm font-semibold text-zinc-900">
            <Icons.Phone className="h-4 w-4" /> Text / Call
          </div>
          <div className="mt-2 text-xl font-bold">(407) 234-5863</div>
          <div className="mt-1 text-sm text-zinc-600">Fastest response by text.</div>
        </div>

        <div className="rounded-2xl bg-white p-5 shadow-sm border border-zinc-100">
          <div className="flex items-center gap-2 text-sm font-semibold text-zinc-900">
            <Icons.Clock className="h-4 w-4" /> Hours
          </div>
          <div className="mt-2 text-xl font-bold">Mon–Sat</div>
          <div className="mt-1 text-sm text-zinc-600">Flexible scheduling available.</div>
        </div>

        <div className="rounded-2xl bg-white p-5 shadow-sm border border-zinc-100">
          <div className="flex items-center gap-2 text-sm font-semibold text-zinc-900">
            <Icons.MapPin className="h-4 w-4" /> Service Area
          </div>
          <div className="mt-2 text-xl font-bold">Carolinas</div>
          <div className="mt-1 text-sm text-zinc-600">Charlotte • Rock Hill • Spartanburg</div>
        </div>
      </div>
    </section>
  );
};

const ServicesCards = () => {
  const items = [
    { title: "Diagnostics", desc: "No-start, stalling, misfires, codes.", Icon: Icons.Gauge },
    { title: "Brakes", desc: "Pads/rotors, noise, pulsation checks.", Icon: Icons.ShieldCheck },
    { title: "Battery / Charging", desc: "Battery, alternator testing & replacement.", Icon: Icons.Battery },
    { title: "Tune-up", desc: "Plugs, coils, sensors (as needed).", Icon: Icons.Wrench },
    { title: "Cooling", desc: "Leaks, hoses, thermostat diagnostics.", Icon: Icons.Fuel },
    { title: "Pre-purchase Check", desc: "Quick inspection before you buy.", Icon: Icons.Car },
  ];

  return (
    <section id="services" className="mx-auto max-w-6xl px-4 py-14">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-6">
        <div>
          <h2 className="text-3xl font-bold">Common Services</h2>
          <p className="mt-2 text-zinc-600">
            Mechanic-demo style: simple cards, clear benefits, easy CTA.
          </p>
        </div>
        <a
          href="#contact"
          className="hidden rounded-2xl bg-zinc-900 px-5 py-3 text-sm font-semibold text-white md:inline-block hover:bg-zinc-800 transition-colors"
        >
          Text for availability
        </a>
      </div>

      <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {items.map(({ title, desc, Icon }) => (
          <div key={title} className="rounded-3xl border border-zinc-200 bg-white p-6 shadow-sm hover:shadow-md transition-shadow">
            <div className="flex items-center gap-3">
              <div className="rounded-2xl border border-zinc-200 p-3 bg-zinc-50">
                <Icon className="h-5 w-5 text-zinc-900" />
              </div>
              <div className="text-lg font-semibold">{title}</div>
            </div>
            <p className="mt-3 text-sm text-zinc-600">{desc}</p>
            <a href="#contact" className="mt-5 inline-block text-sm font-semibold text-zinc-900 hover:text-zinc-600">
              Get pricing →
            </a>
          </div>
        ))}
      </div>
    </section>
  );
};

const Testimonials = () => {
  const quotes = [
    { name: "Customer A", text: "Showed up on time, diagnosed fast, and fixed it without upselling." },
    { name: "Customer B", text: "Clear communication and fair pricing. Saved me a tow." },
    { name: "Customer C", text: "Professional tools and real troubleshooting. Highly recommend." },
  ];
  
  const [current, setCurrent] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrent((prev) => (prev + 1) % quotes.length);
    }, 4000);
    return () => clearInterval(timer);
  }, [quotes.length]);

  return (
    <section className="bg-zinc-50 py-14">
      <div className="mx-auto max-w-6xl px-4">
        <h2 className="text-3xl font-bold">Reviews</h2>
        <p className="mt-2 text-zinc-600">Short slider like the theme demo.</p>

        <div className="mt-8 rounded-3xl border border-zinc-200 bg-white p-6 shadow-sm relative overflow-hidden min-h-[160px] flex items-center">
            {quotes.map((q, idx) => (
                <div 
                  key={idx} 
                  className={`absolute w-full px-6 transition-all duration-500 ease-in-out transform ${
                    idx === current 
                      ? "opacity-100 translate-x-0" 
                      : idx < current 
                        ? "opacity-0 -translate-x-10" 
                        : "opacity-0 translate-x-10"
                  }`}
                >
                    <div className="text-xl font-semibold leading-relaxed">“{q.text}”</div>
                    <div className="mt-4 text-sm font-bold text-zinc-600">— {q.name}</div>
                </div>
            ))}
        </div>
      </div>
    </section>
  );
};

const StatementTicker = () => {
  const lines = [
    "Diagnose first. Fix what’s confirmed.",
    "Mobile service — we come to you.",
    "Clear communication and clean work.",
    "No tow if you can avoid it.",
  ];
  const [index, setIndex] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setIndex((prev) => (prev + 1) % lines.length);
    }, 2200);
    return () => clearInterval(timer);
  }, [lines.length]);

  return (
    <section className="border-y border-zinc-200 bg-white py-6">
      <div className="mx-auto max-w-6xl px-4">
        <div className="text-center text-sm font-semibold text-zinc-700 h-6 overflow-hidden relative">
            {lines.map((line, i) => (
                <div key={i} className={`absolute w-full transition-all duration-500 ${i === index ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"}`}>
                    {line}
                </div>
            ))}
        </div>
      </div>
    </section>
  );
};

const BrandsCarousel = () => {
  const brands = ["Audi", "BMW", "Ford", "Toyota", "Honda", "Nissan", "Jeep", "Chevy"];
  
  return (
    <section className="mx-auto max-w-6xl px-4 py-14">
      <div className="flex items-end justify-between gap-6 mb-8">
        <div>
          <h2 className="text-3xl font-bold">Makes We Commonly See</h2>
          <p className="mt-2 text-zinc-600">Simple loop carousel (like the demo’s logo strip).</p>
        </div>
      </div>

      <div className="rounded-3xl border border-zinc-200 bg-white p-5 shadow-sm overflow-hidden">
        {/* Simple scrolling flex container */}
        <div className="flex gap-4 overflow-x-auto hide-scrollbar pb-2">
           {brands.map((b) => (
             <div key={b} className="flex-none w-32 h-16 flex items-center justify-center rounded-2xl border border-zinc-200 bg-zinc-50 text-sm font-semibold text-zinc-600">
               {b}
             </div>
           ))}
           {/* Duplicate for visual length */}
           {brands.map((b) => (
             <div key={`${b}-dup`} className="flex-none w-32 h-16 flex items-center justify-center rounded-2xl border border-zinc-200 bg-zinc-50 text-sm font-semibold text-zinc-600">
               {b}
             </div>
           ))}
        </div>
      </div>
    </section>
  );
};

const InteractiveBoxes = () => {
  const boxes = [
    { title: "No-Start / Stalling", bullets: ["Fuel / spark checks", "Starter + battery testing", "Scan + data review"] },
    { title: "Warning Lights", bullets: ["Check engine light", "ABS / traction", "Charging system"] },
    { title: "Maintenance", bullets: ["Oil & filters", "Spark plugs", "Belts / hoses"] },
  ];

  return (
    <section className="bg-zinc-50 py-14">
      <div className="mx-auto max-w-6xl px-4">
        <h2 className="text-3xl font-bold">What We’re Great At</h2>
        <p className="mt-2 text-zinc-600">
          “Interactive boxes” feel from the theme — clean cards with bullet points.
        </p>

        <div className="mt-8 grid gap-5 md:grid-cols-3">
          {boxes.map((b) => (
            <div
              key={b.title}
              className="group rounded-3xl border border-zinc-200 bg-white p-6 shadow-sm transition hover:-translate-y-1 hover:shadow-md duration-300"
            >
              <div className="text-lg font-semibold">{b.title}</div>
              <ul className="mt-3 space-y-2 text-sm text-zinc-600">
                {b.bullets.map((x) => (
                  <li key={x}>• {x}</li>
                ))}
              </ul>
              <a href="#contact" className="mt-5 inline-block text-sm font-semibold text-zinc-900 group-hover:text-blue-600 transition-colors">
                Ask about this →
              </a>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

const MapCta = () => {
  return (
    <section className="mx-auto max-w-6xl px-4 py-14">
      <div className="grid gap-6 lg:grid-cols-2">
        <div className="rounded-3xl border border-zinc-200 bg-white p-7 shadow-sm">
          <h2 className="text-3xl font-bold">Ready to schedule?</h2>
          <p className="mt-2 text-zinc-600">
            Text your address/ZIP, your vehicle info, and the best time window.
          </p>

          <div className="mt-6 rounded-2xl bg-zinc-50 p-5 text-sm border border-zinc-100">
            <div className="font-semibold text-zinc-900">Text:</div>
            <div className="mt-1 text-2xl font-bold text-zinc-900">(407) 234-5863</div>
            <div className="mt-2 text-zinc-600">
              Include: year/make/model, symptoms, codes, and any parts you already have.
            </div>
          </div>

          <div className="mt-6 flex flex-wrap gap-3">
            <a
              href="sms:+14072345863"
              className="rounded-2xl bg-zinc-900 px-5 py-3 text-sm font-semibold text-white hover:bg-zinc-800 transition-colors"
            >
              Text Now
            </a>
            <a
              href="#services"
              className="rounded-2xl border border-zinc-200 px-5 py-3 text-sm font-semibold text-zinc-700 hover:bg-zinc-50 transition-colors"
            >
              Review Services
            </a>
          </div>
        </div>

        <div className="overflow-hidden rounded-3xl border border-zinc-200 bg-white shadow-sm h-[360px] relative">
          <iframe
            title="Service Area"
            className="w-full h-full border-0"
            loading="lazy"
            src="https://www.google.com/maps?q=Charlotte%2C%20NC&output=embed"
          />
          <div className="absolute inset-0 pointer-events-none border border-black/5 rounded-3xl"></div>
        </div>
      </div>
    </section>
  );
};

const Footer = () => {
  return (
    <footer className="border-t border-zinc-200 bg-white">
      <div className="mx-auto max-w-6xl px-4 py-10">
        <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
          <div className="text-sm text-zinc-600">
            © {new Date().getFullYear()} Service Hub — Mobile Mechanic
          </div>
          <div className="text-sm text-zinc-600">
            Text: <span className="font-semibold text-zinc-900">(407) 234-5863</span>
          </div>
        </div>
      </div>
    </footer>
  );
};

const App = () => {
  return (
    <main className="bg-white min-h-screen">
      <HeroSlider />
      <ContactStrip />
      <ServicesCards />
      <Testimonials />
      <StatementTicker />
      <BrandsCarousel />
      <InteractiveBoxes />
      <MapCta />
      <Footer />
    </main>
  );
};

const root = createRoot(document.getElementById("root")!);
root.render(<App />);

import React from "react";
import { createRoot } from "react-dom/client";

/**
 * Landing page layout updated to match the provided mock:
 * - Photo hero + overlay + dual CTAs
 * - 3-column info strip (phone / hours / service area)
 * - 3 common service cards
 * - Statement line
 * - Makes strip
 * - Bottom CTA w/ map
 */

const PhoneIcon = ({ className = "h-6 w-6" }: { className?: string }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className={className} aria-hidden="true">
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      d="M2 5.5C2 4.12 3.12 3 4.5 3h2.2c.83 0 1.57.51 1.88 1.28l1 2.52c.25.62.1 1.33-.37 1.8l-1.3 1.3a14.6 14.6 0 006.4 6.4l1.3-1.3c.47-.47 1.18-.62 1.8-.37l2.52 1c.77.31 1.28 1.05 1.28 1.88V19.5c0 1.38-1.12 2.5-2.5 2.5h-.7C9.2 22 2 14.8 2 5.5z"
    />
  </svg>
);

const ClockIcon = ({ className = "h-6 w-6" }: { className?: string }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className={className} aria-hidden="true">
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 8v5l3 2" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
  </svg>
);

const PinIcon = ({ className = "h-6 w-6" }: { className?: string }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className={className} aria-hidden="true">
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      d="M12 21s7-4.44 7-11a7 7 0 10-14 0c0 6.56 7 11 7 11z"
    />
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 10.5a2.5 2.5 0 100-5 2.5 2.5 0 000 5z" />
  </svg>
);

const GaugeIcon = ({ className = "h-6 w-6" }: { className?: string }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className={className} aria-hidden="true">
    <path strokeLinecap="round" strokeLinejoin="round" d="M6.4 18.4A9 9 0 1117.6 18.4" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 13l3-3" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M6 18h12" />
  </svg>
);

const ShieldIcon = ({ className = "h-6 w-6" }: { className?: string }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className={className} aria-hidden="true">
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      d="M12 22s8-4 8-10V6l-8-4-8 4v6c0 6 8 10 8 10z"
    />
    <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4" />
  </svg>
);

const WrenchIcon = ({ className = "h-6 w-6" }: { className?: string }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className={className} aria-hidden="true">
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      d="M21 2l-2 2m-2 2l-4 4m6-6a5 5 0 11-7.07 7.07L5 18l-3 1 1-3 6.07-6.07"
    />
  </svg>
);

const Container = ({ children }: { children: React.ReactNode }) => (
  <div className="mx-auto max-w-6xl px-4">{children}</div>
);

const Hero = () => {
  return (
    <section className="relative overflow-hidden">
      {/* Background image */}
      <div
        className="absolute inset-0 bg-center bg-cover"
        style={{ backgroundImage: "url(/hero-bg.png)" }}
      />
      {/* Dark overlay for readable copy */}
      <div className="absolute inset-0 bg-gradient-to-r from-black/85 via-black/55 to-black/20" />

      <Container>
        <div className="relative py-16 sm:py-20">
          <div className="grid gap-10 md:grid-cols-2 md:items-center">
            <div className="text-white">
              <div className="text-xs sm:text-sm font-semibold tracking-[0.25em] text-white/80">
                ALEX DOSS MOBILE MECHANIC
              </div>

              <h1 className="mt-4 text-4xl sm:text-5xl font-extrabold leading-tight">
                Mobile Mechanic —
                <br />
                Diagnostics &amp; Repairs at Your Location
              </h1>

              <p className="mt-4 text-base sm:text-lg text-white/85 max-w-xl">
                No tow. No guessing. Clear next steps after diagnosis.
              </p>

              <div className="mt-8 flex flex-wrap gap-3">
                <a
                  href="sms:+14072345863"
                  className="rounded-md bg-white px-6 py-3 text-sm font-semibold text-zinc-900 shadow hover:bg-zinc-100 transition"
                >
                  Text to Schedule
                </a>
                <a
                  href="#services"
                  className="rounded-md border border-white/40 bg-white/10 px-6 py-3 text-sm font-semibold text-white hover:bg-white/15 transition"
                >
                  View Common Repairs
                </a>
              </div>

              <div className="mt-8 text-sm font-semibold text-white/80">
                Serving: Charlotte / Rock Hill / Spartanburg
              </div>
            </div>

            {/* What to text box (desktop only, like the mock) */}
            <div className="hidden md:block">
              <div className="ml-auto max-w-md overflow-hidden rounded-xl border border-white/20 bg-white/80 shadow-lg">
                <div className="p-5">
                  <div className="text-lg font-bold text-zinc-900">What to text us</div>
                  <ul className="mt-3 space-y-2 text-sm text-zinc-700">
                    <li>• Address / ZIP + best time window</li>
                    <li>• Year / make / model + symptoms</li>
                    <li>• Any codes (if you have them)</li>
                    <li>• Photos/video if relevant</li>
                  </ul>
                </div>
                <div className="bg-zinc-900/60 px-5 py-4 text-white">
                  <div className="text-sm font-semibold">Example:</div>
                  <div className="mt-1 text-sm text-white/95">
                    ‘2009 Honda Accord. Cranks but won’t start. Charlotte. Tuesday morning’
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Container>
    </section>
  );
};

const InfoStrip = () => {
  return (
    <section className="bg-zinc-100 border-y border-zinc-200">
      <Container>
        <div className="grid md:grid-cols-3 divide-y md:divide-y-0 md:divide-x divide-zinc-200">
          <div className="flex items-center gap-4 px-6 py-6">
            <div className="rounded-full bg-zinc-800 p-3 text-white">
              <PhoneIcon className="h-6 w-6" />
            </div>
            <div>
              <div className="text-lg font-extrabold text-zinc-900">Text / Call</div>
              <a href="sms:+14072345863" className="text-2xl font-extrabold text-zinc-900 hover:underline">(407) 234-5863</a>
              <div className="mt-1 text-sm italic text-zinc-600">Fast response by text</div>
            </div>
          </div>

          <div className="flex items-center gap-4 px-6 py-6">
            <div className="rounded-full bg-zinc-800 p-3 text-white">
              <ClockIcon className="h-6 w-6" />
            </div>
            <div>
              <div className="text-lg font-extrabold text-zinc-900">Hours</div>
              <div className="text-base font-semibold text-zinc-900">Mon—Sat</div>
              <div className="mt-1 text-sm italic text-zinc-600">Flexible scheduling available</div>
            </div>
          </div>

          <div className="flex items-center gap-4 px-6 py-6">
            <div className="rounded-full bg-zinc-800 p-3 text-white">
              <PinIcon className="h-6 w-6" />
            </div>
            <div>
              <div className="text-lg font-extrabold text-zinc-900">Service Area</div>
              <div className="text-base font-semibold text-zinc-900">Carolinas</div>
              <div className="mt-1 text-sm italic text-zinc-600">Charlotte / Rock Hill / Spartanburg</div>
            </div>
          </div>
        </div>
      </Container>
    </section>
  );
};

type ServiceCardItem = {
  title: string;
  desc: string;
  Icon: (p: { className?: string }) => JSX.Element;
};

const CommonServices = () => {
  const items: ServiceCardItem[] = [
    {
      title: "No-Start / Stalling",
      desc: "Crank/no start, stalls, intermittent issues.",
      Icon: GaugeIcon,
    },
    {
      title: "Brakes",
      desc: "Pads/rotors, noise, vibration, pull diagnosis.",
      Icon: ShieldIcon,
    },
    {
      title: "Check Engine Light",
      desc: "Misfires, sensors, driveability diagnostics.",
      Icon: WrenchIcon,
    },
  ];

  return (
    <section id="services" className="bg-white py-14">
      <Container>
        <div className="flex flex-col gap-3 sm:flex-row sm:items-end">
          <h2 className="text-4xl font-extrabold text-zinc-900">Common Services</h2>
          <p className="sm:ml-4 text-zinc-600">Dependable repairs - on your terms.</p>
        </div>

        <div className="mt-8 grid gap-6 md:grid-cols-3">
          {items.map(({ title, desc, Icon }) => (
            <div
              key={title}
              className="relative overflow-hidden rounded-xl border border-zinc-200 bg-zinc-50 shadow-sm"
            >
              {/* Faded icon area on right */}
              <div className="absolute inset-y-0 right-0 w-44 bg-gradient-to-l from-white/70 to-transparent" />
              <div className="absolute right-6 top-1/2 -translate-y-1/2 text-zinc-900/20">
                <Icon className="h-24 w-24" />
              </div>

              <div className="relative p-6">
                <div className="flex items-center gap-3">
                  <div className="rounded-lg bg-white p-2.5 text-zinc-900 shadow-sm border border-zinc-200">
                    <Icon className="h-5 w-5" />
                  </div>
                  <div className="text-xl font-extrabold text-zinc-900">{title}</div>
                </div>

                <p className="mt-4 max-w-[22rem] text-sm text-zinc-600">{desc}</p>

                <div className="mt-6 pt-4 border-t border-zinc-200">
                  <a
                    href="#contact"
                    className="inline-flex items-center gap-2 text-sm font-semibold text-blue-700 hover:text-blue-800"
                  >
                    Get pricing <span aria-hidden="true">→</span>
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>
      </Container>
    </section>
  );
};

const StatementLine = () => (
  <section className="bg-white border-t border-zinc-200">
    <Container>
      <div className="py-10 text-center">
        <div className="text-xl sm:text-2xl font-semibold italic text-slate-800">
          Diagnose first. Fix what’s confirmed.
        </div>
      </div>
    </Container>
  </section>
);

const MakesStrip = () => {
  const makes = ["Audi", "BMW", "Ford", "Toyota", "Honda", "GMC"];

  return (
    <section className="bg-zinc-50 py-14">
      <Container>
        <h2 className="text-3xl font-extrabold text-center text-zinc-900">Makes We Commonly See</h2>

        <div className="mt-6 rounded-xl border border-zinc-200 bg-white shadow-sm px-6 py-5">
          <div className="flex flex-wrap items-center justify-center gap-x-10 gap-y-4">
            {makes.map((m) => (
              <div
                key={m}
                className="rounded-full border border-zinc-200 bg-zinc-50 px-6 py-2 text-sm font-semibold text-zinc-600"
              >
                {m}
              </div>
            ))}
          </div>
        </div>
      </Container>
    </section>
  );
};

const BottomCta = () => {
  return (
    <section id="contact" className="bg-gradient-to-b from-slate-800 to-slate-950 text-white">
      <Container>
        <div className="grid gap-8 py-14 lg:grid-cols-2 lg:items-center">
          <div>
            <h2 className="text-3xl sm:text-4xl font-extrabold">Ready to schedule?</h2>
            <div className="mt-4 text-xl sm:text-2xl font-semibold">
              Text: <span className="font-extrabold">(407) 234-5863</span>
            </div>

            <div className="mt-6 flex flex-wrap gap-3">
              <a
                href="sms:+14072345863"
                className="rounded-md bg-blue-600 px-6 py-3 text-sm font-semibold text-white shadow hover:bg-blue-500 transition"
              >
                Text Now
              </a>
              <a
                href="#services"
                className="rounded-md border border-white/20 bg-white/10 px-6 py-3 text-sm font-semibold text-white hover:bg-white/15 transition"
              >
                Review Services
              </a>
            </div>
          </div>

          <div className="overflow-hidden rounded-xl border border-white/10 shadow-lg h-[280px] sm:h-[320px]">
            <iframe
              title="Service Area"
              className="h-full w-full border-0"
              loading="lazy"
              src="https://www.google.com/maps?q=Charlotte%2C%20NC&output=embed"
            />
          </div>
        </div>
      </Container>

      <div className="border-t border-white/10">
        <Container>
          <div className="flex flex-col gap-2 py-5 text-sm text-white/70 sm:flex-row sm:items-center sm:justify-between">
            <div>© 2024 Alex Doss Mobile Mechanic</div>
            <div>
              Text: <span className="font-semibold text-white/90">(407) 234-5863</span>
            </div>
          </div>
        </Container>
      </div>
    </section>
  );
};

const App = () => {
  return (
    <main className="min-h-screen bg-white">
      <Hero />
      <InfoStrip />
      <CommonServices />
      <StatementLine />
      <MakesStrip />
      <BottomCta />
    </main>
  );
};

createRoot(document.getElementById("root")!).render(<App />);

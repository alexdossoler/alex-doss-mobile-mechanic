/** @type {import('next').NextConfig} */
const repo = "alex-doss-mobile-mechanic";

module.exports = {
  output: "export",
  basePath: `/${repo}`,
  assetPrefix: `/${repo}/`,
  images: { unoptimized: true },
  trailingSlash: true,
};

"use client";

import { Swiper, SwiperSlide } from "swiper/react";
import { Autoplay } from "swiper/modules";

const brands = ["Audi", "BMW", "Ford", "Toyota", "Honda", "Nissan", "Jeep", "Chevy"];

export default function BrandsCarousel() {
  return (
    <section className="mx-auto max-w-6xl px-4 py-14">
      <div className="flex items-end justify-between gap-6">
        <div>
          <h2 className="text-3xl font-bold">Makes We Commonly See</h2>
          <p className="mt-2 text-zinc-600">Simple loop carousel (like the demo's logo strip).</p>
        </div>
      </div>

      <div className="mt-8 rounded-3xl border border-zinc-200 bg-white p-5 shadow-sm">
        <Swiper
          modules={[Autoplay]}
          autoplay={{ delay: 1600, disableOnInteraction: false }}
          loop
          spaceBetween={12}
          breakpoints={{
            0: { slidesPerView: 2.2 },
            640: { slidesPerView: 4.2 },
            1024: { slidesPerView: 6.2 },
          }}
        >
          {brands.map((b) => (
            <SwiperSlide key={b}>
              <div className="flex h-16 items-center justify-center rounded-2xl border border-zinc-200 bg-zinc-50 text-sm font-semibold">
                {b}
              </div>
            </SwiperSlide>
          ))}
        </Swiper>
      </div>
    </section>
  );
}

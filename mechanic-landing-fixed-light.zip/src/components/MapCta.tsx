export default function MapCta() {
  return (
    <section className="mx-auto max-w-6xl px-4 py-14">
      <div className="grid gap-6 lg:grid-cols-2">
        <div className="rounded-3xl border border-zinc-200 bg-white p-7 shadow-sm">
          <h2 className="text-3xl font-bold">Ready to schedule?</h2>
          <p className="mt-2 text-zinc-600">
            Text your address/ZIP, your vehicle info, and the best time window.
          </p>

          <div className="mt-6 rounded-2xl bg-zinc-50 p-5 text-sm">
            <div className="font-semibold">Text:</div>
            <div className="mt-1 text-2xl font-bold">(407) 234-5863</div>
            <div className="mt-2 text-zinc-600">
              Include: year/make/model, symptoms, codes, and any parts you already have.
            </div>
          </div>

          <div className="mt-6 flex flex-wrap gap-3">
            <a
              href="sms:+14072345863"
              className="rounded-2xl bg-zinc-900 px-5 py-3 text-sm font-semibold text-white"
            >
              Text Now
            </a>
            <a
              href="#services"
              className="rounded-2xl border border-zinc-200 px-5 py-3 text-sm font-semibold"
            >
              Review Services
            </a>
          </div>
        </div>

        <div className="overflow-hidden rounded-3xl border border-zinc-200 bg-white shadow-sm">
          <iframe
            title="Service Area"
            className="h-[360px] w-full"
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
            src="https://www.google.com/maps?q=Charlotte%2C%20NC&output=embed"
          />
        </div>
      </div>
    </section>
  );
}

import { Phone, Clock, MapPin } from "lucide-react";

export default function ContactStrip() {
  return (
    <section id="contact" className="border-b border-zinc-200 bg-zinc-50">
      <div className="mx-auto grid max-w-6xl gap-4 px-4 py-8 md:grid-cols-3">
        <div className="rounded-2xl bg-white p-5 shadow-sm">
          <div className="flex items-center gap-2 text-sm font-semibold">
            <Phone className="h-4 w-4" /> Text / Call
          </div>
          <div className="mt-2 text-xl font-bold">(407) 234-5863</div>
          <div className="mt-1 text-sm text-zinc-600">Fastest response by text.</div>
        </div>

        <div className="rounded-2xl bg-white p-5 shadow-sm">
          <div className="flex items-center gap-2 text-sm font-semibold">
            <Clock className="h-4 w-4" /> Hours
          </div>
          <div className="mt-2 text-xl font-bold">Mon–Sat</div>
          <div className="mt-1 text-sm text-zinc-600">Flexible scheduling available.</div>
        </div>

        <div className="rounded-2xl bg-white p-5 shadow-sm">
          <div className="flex items-center gap-2 text-sm font-semibold">
            <MapPin className="h-4 w-4" /> Service Area
          </div>
          <div className="mt-2 text-xl font-bold">Carolinas</div>
          <div className="mt-1 text-sm text-zinc-600">Charlotte • Rock Hill • Spartanburg</div>
        </div>
      </div>
    </section>
  );
}

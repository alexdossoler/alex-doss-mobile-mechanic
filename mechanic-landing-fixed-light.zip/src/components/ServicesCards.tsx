import { Wrench, Battery, Gauge, Car, Fuel, ShieldCheck } from "lucide-react";

const items = [
  { title: "No-Start / Stalling", desc: "Won't start? We diagnose fuel, spark, battery & more on-site.", Icon: Car },
  { title: "Brakes", desc: "Pads, rotors, noise, pulsation — full brake inspection & repair.", Icon: ShieldCheck },
  { title: "Diagnostics", desc: "Check engine light, misfires, codes — real troubleshooting.", Icon: Gauge },
  { title: "Battery / Charging", desc: "Battery, alternator testing & replacement.", Icon: Battery },
  { title: "Tune-up", desc: "Plugs, coils, sensors (as needed).", Icon: Wrench },
  { title: "Pre-purchase Check", desc: "Quick inspection before you buy.", Icon: Car },
];

export default function ServicesCards() {
  return (
    <section id="services" className="mx-auto max-w-6xl px-4 py-14">
      <div className="flex items-end justify-between gap-6">
        <div>
          <h2 className="text-3xl font-bold">Common Services</h2>
          <p className="mt-2 text-zinc-600">
            Mechanic-demo style: simple cards, clear benefits, easy CTA.
          </p>
        </div>
        <a
          href="#contact"
          className="hidden rounded-2xl bg-zinc-900 px-5 py-3 text-sm font-semibold text-white md:inline-block"
        >
          Text for availability
        </a>
      </div>

      <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {items.map(({ title, desc, Icon }) => (
          <div key={title} className="rounded-3xl border border-zinc-200 bg-white p-6 shadow-sm">
            <div className="flex items-center gap-3">
              <div className="rounded-2xl border border-zinc-200 p-3">
                <Icon className="h-5 w-5" />
              </div>
              <div className="text-lg font-semibold">{title}</div>
            </div>
            <p className="mt-3 text-sm text-zinc-600">{desc}</p>
            <a href="#contact" className="mt-5 inline-block text-sm font-semibold text-zinc-900">
              Get pricing →
            </a>
          </div>
        ))}
      </div>
    </section>
  );
}

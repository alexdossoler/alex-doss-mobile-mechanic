"use client";

import { Swiper, SwiperSlide } from "swiper/react";
import { Autoplay, Pagination, EffectFade } from "swiper/modules";

const slides = [
  {
    kicker: "Mobile Mechanic",
    title: "Honest Diagnostics First, Repairs Second",
    body: "No tow. No waiting room. Clear pricing after diagnosis.",
    cta: "Text to Schedule",
    href: "#contact",
  },
  {
    kicker: "Fast Turnarounds",
    title: "Brake • Battery • No-Start • Sensors",
    body: "We come to you with pro tools and real troubleshooting.",
    cta: "See Services",
    href: "#services",
  },
  {
    kicker: "Straight Talk",
    title: "Fix What's Confirmed",
    body: "We diagnose first and only replace what's necessary.",
    cta: "Get a Quote",
    href: "#contact",
  },
];

export default function HeroSlider() {
  return (
    <section className="relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-zinc-950 to-zinc-900" />
      <div className="absolute inset-0 opacity-20 [background:radial-gradient(circle_at_30%_20%,white,transparent_55%)]" />
      <div className="relative mx-auto max-w-6xl px-4 py-16 sm:py-20">
        <Swiper
          modules={[Autoplay, Pagination, EffectFade]}
          effect="fade"
          pagination={{ clickable: true }}
          autoplay={{ delay: 4500, disableOnInteraction: false }}
          slidesPerView={1}
          watchSlidesProgress
          className="rounded-3xl border border-white/10 bg-white/5 backdrop-blur"
        >
          {slides.map((s) => (
            <SwiperSlide key={s.title}>
              <div className="grid gap-10 p-8 sm:p-12 md:grid-cols-2 md:items-center">
                <div className="text-white">
                  <div className="text-sm font-semibold tracking-widest text-white/70">
                    {s.kicker}
                  </div>
                  <h1 className="mt-3 text-3xl font-bold leading-tight sm:text-5xl">
                    {s.title}
                  </h1>
                  <p className="mt-4 max-w-prose text-lg text-white/80">{s.body}</p>
                  <div className="mt-7 flex flex-wrap gap-3">
                    <a
                      href={s.href}
                      className="rounded-2xl bg-white px-5 py-3 text-sm font-semibold text-zinc-900 shadow"
                    >
                      {s.cta}
                    </a>
                    <a
                      href="#services"
                      className="rounded-2xl border border-white/20 px-5 py-3 text-sm font-semibold text-white"
                    >
                      View Common Repairs
                    </a>
                  </div>
                  <div className="mt-6 text-sm text-white/60">
                    Serving: Charlotte • Rock Hill • Spartanburg (and nearby)
                  </div>
                </div>

                <div className="rounded-3xl border border-white/10 bg-white/5 p-6 text-white">
                  <div className="text-sm font-semibold text-white/70">What to text us</div>
                  <ul className="mt-3 space-y-2 text-sm text-white/80">
                    <li>• Address / ZIP + best time window</li>
                    <li>• Year / make / model + symptoms</li>
                    <li>• Any codes (if you have them)</li>
                    <li>• Photos/video if relevant</li>
                  </ul>
                  <div className="mt-5 rounded-2xl bg-zinc-950/40 p-4 text-sm">
                    <div className="font-semibold">Example</div>
                    <div className="mt-1 text-white/75">
                      "2014 Audi SQ5. Rough idle + oil leak. Rock Hill. Friday 2–5pm."
                    </div>
                  </div>
                </div>
              </div>
            </SwiperSlide>
          ))}
        </Swiper>
      </div>
    </section>
  );
}

import HeroSlider from "@/components/HeroSlider";
import ContactStrip from "@/components/ContactStrip";
import ServicesCards from "@/components/ServicesCards";
import Testimonials from "@/components/Testimonials";
import StatementTicker from "@/components/StatementTicker";
import BrandsCarousel from "@/components/BrandsCarousel";
import InteractiveBoxes from "@/components/InteractiveBoxes";
import MapCta from "@/components/MapCta";
import Footer from "@/components/Footer";

export default function Page() {
  return (
    <main>
      <HeroSlider />
      <ContactStrip />
      <ServicesCards />
      <Testimonials />
      <StatementTicker />
      <BrandsCarousel />
      <InteractiveBoxes />
      <MapCta />
      <Footer />
    </main>
  );
}
